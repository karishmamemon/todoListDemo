﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Sample : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage2.Text = "Make you list here...";
    }

    //Method for button AddToDo. this will create an item in the checkbox window
    protected void btnAddToDo_Click(object sender, EventArgs e)
    {
        cblTodoCheckBox.Items.Add(txtAddToDo.Text + "  on " + DateTime.Now);   
    }

    //Method to delete the list item from checkbox list
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        if(cblTodoCheckBox.SelectedIndex != -1)
        {
            cblTodoCheckBox.Items.RemoveAt(cblTodoCheckBox.SelectedIndex);
        }
    }

    protected void Exit_Click(object sender, EventArgs e)
    {
        Response.Redirect("LoginPage.aspx");
    }
}