﻿using System;

public partial class LoginPage : System.Web.UI.Page
{
    //Global variables
    public string userName = "test";
    private const string password = "pwd123";
    
    //Method on page load
    protected void Page_Load(object sender, EventArgs e)
    {
        rfvUsername.Visible = false;
        rfvPassword.Visible = false;
        txtUsername.Focus();
        
    }

    //Method on click of login button
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //using try block for better performance and to catch all kinds of runtime exception using catch block
        try
        {
                string userName = txtUsername.Text;
                string password = txtPassword.Text;
                //Condition to check if the username and password is entered correctly
                if (txtUsername.Text == "test" && txtPassword.Text == "pwd123")
                {
                    lblMessage.Text = "Login Success..!!";
                    //Calling the Sample.aspx page where we have our ToDo list functionality enabled
                    Response.Redirect("Sample.aspx");
                }
                else
                {
                    //Error message in case the user name or password is incorrect.
                    lblMessage.Text = "User Name & Password is incorrect. Try again!!";

                }
            
        }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            
        }
    }





    

   